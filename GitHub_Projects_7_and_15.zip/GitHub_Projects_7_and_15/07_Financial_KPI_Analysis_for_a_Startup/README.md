# Financial KPI Analysis for a Startup

## Objective
Analyze monthly revenue, burn rate, CAC, LTV, LTV:CAC and annualized run rate. Includes cohort retention data.

## Files
- `data/startup_monthly_financials.csv` — synthetic 24-month financial dataset
- `data/customer_cohort_data.csv` — synthetic monthly cohort retention data
- `src/analyze_financial_kpis.py` — calculations and charts
- `Financial_KPI_Model_Template.xlsx` — Excel workbook template
- `outputs/` — generated KPI tables and visualizations

## Run
```bash
pip install -r requirements.txt
python src/analyze_financial_kpis.py
```

## KPI definitions
- Burn rate = max(total expenses − revenue, 0)
- CAC = marketing spend / new customers
- Estimated LTV = monthly gross profit per active customer / monthly churn assumption
- LTV:CAC = estimated LTV / CAC
- Annualized run rate = monthly revenue × 12

**Assumptions and limitations:** Dataset is synthetic. Estimated LTV uses an illustrative 5% monthly churn assumption because customer-level transaction history is not provided. Replace assumptions with verified company data for real-world use. This is an educational analysis, not investment advice.

## Tableau dashboard
Suggested views: KPI cards, revenue vs expenses trend, burn rate trend, CAC and LTV trend, and cohort retention heatmap using `customer_cohort_data.csv`.
