from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT/"data/startup_monthly_financials.csv", parse_dates=["month"]).sort_values("month")
out = ROOT/"outputs"
out.mkdir(exist_ok=True)

df["burn_rate"] = (df["total_expenses"]-df["revenue"]).clip(lower=0)
df["net_cash_flow"] = df["revenue"]-df["total_expenses"]
df["annualized_run_rate"] = df["revenue"]*12
df["cac"] = df["marketing_spend"]/df["new_customers"].replace(0, pd.NA)
# Illustrative estimate: assumes 5% monthly churn; replace with observed churn for real analysis.
churn_assumption = 0.05
df["monthly_gross_profit_per_customer"] = df["gross_profit"]/df["active_customers"]
df["estimated_ltv"] = df["monthly_gross_profit_per_customer"]/churn_assumption
df["ltv_cac_ratio"] = df["estimated_ltv"]/df["cac"]
df.to_csv(out/"financial_kpi_results.csv", index=False)

summary = pd.DataFrame({"KPI":["Total revenue","Average monthly revenue","Average monthly burn","Latest annualized run rate","Average CAC","Average estimated LTV","Average LTV:CAC"],
"value":[df.revenue.sum(),df.revenue.mean(),df.burn_rate.mean(),df.annualized_run_rate.iloc[-1],df.cac.mean(),df.estimated_ltv.mean(),df.ltv_cac_ratio.mean()]})
summary.to_csv(out/"kpi_summary.csv", index=False)

fig,ax=plt.subplots(figsize=(10,5))
ax.plot(df.month,df.revenue,label="Revenue")
ax.plot(df.month,df.total_expenses,label="Total expenses")
ax.set(title="Monthly Revenue vs Expenses",xlabel="Month",ylabel="Amount (₹)")
ax.legend(); ax.grid(alpha=.25); fig.tight_layout()
fig.savefig(out/"revenue_vs_expenses.png",dpi=160); plt.close(fig)

fig,ax=plt.subplots(figsize=(10,5))
ax.plot(df.month,df.burn_rate)
ax.set(title="Monthly Burn Rate",xlabel="Month",ylabel="Burn (₹)")
ax.grid(alpha=.25); fig.tight_layout()
fig.savefig(out/"burn_rate_trend.png",dpi=160); plt.close(fig)
print("Project 7 analysis completed.")
