from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT/"data/shark_tank_startup_sample.csv")
out = ROOT/"outputs"
out.mkdir(exist_ok=True)

industry = df.groupby("industry").agg(
    startup_count=("startup_id","count"),
    deals=("deal_received","sum"),
    total_investment_lakh=("investment_amount_lakh","sum"),
    average_ask_lakh=("amount_asked_lakh","mean")
).reset_index()
industry["deal_rate_pct"] = industry.deals/industry.startup_count*100
industry.to_csv(out/"industry_investment_summary.csv",index=False)

founder = df.groupby("founder_experience").agg(
    startup_count=("startup_id","count"),
    deals=("deal_received","sum"),
    average_investment_lakh=("investment_amount_lakh","mean")
).reset_index()
founder["deal_rate_pct"] = founder.deals/founder.startup_count*100
founder.to_csv(out/"founder_success_summary.csv",index=False)

stage = df.groupby("funding_stage").agg(
    startup_count=("startup_id","count"),
    deals=("deal_received","sum"),
    total_investment_lakh=("investment_amount_lakh","sum")
).reset_index()
stage["deal_rate_pct"] = stage.deals/stage.startup_count*100
stage.to_csv(out/"funding_stage_summary.csv",index=False)

def barplot(data,x,y,title,xlabel,ylabel,filename,kind="bar"):
    fig,ax=plt.subplots(figsize=(9,5))
    data.set_index(x)[y].plot(kind=kind,ax=ax)
    ax.set(title=title,xlabel=xlabel,ylabel=ylabel)
    fig.tight_layout(); fig.savefig(out/filename,dpi=160); plt.close(fig)

barplot(industry.sort_values("total_investment_lakh"),"industry","total_investment_lakh",
        "Total Investment by Industry","Industry","Investment (₹ lakh)","investment_by_industry.png","barh")
barplot(founder,"founder_experience","deal_rate_pct","Deal Rate by Founder Experience",
        "Founder experience","Deal rate (%)","founder_deal_rate.png")
barplot(stage,"funding_stage","deal_rate_pct","Deal Rate by Funding Stage",
        "Funding stage","Deal rate (%)","deal_rate_by_stage.png")
print("Project 15 analysis completed.")
