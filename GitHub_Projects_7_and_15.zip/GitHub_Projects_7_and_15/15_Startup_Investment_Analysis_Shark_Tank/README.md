# Startup Investment Analysis (Shark Tank Data)

## Objective
Analyze startup investment patterns by industry, funding stage and founder experience using a Shark Tank-style dataset.

## Files
- `data/shark_tank_startup_sample.csv` — synthetic startup pitch/investment records
- `src/analyze_startup_investments.py` — analysis and chart generation
- `outputs/` — industry, founder and funding-stage summaries and charts

## Run
```bash
pip install -r requirements.txt
python src/analyze_startup_investments.py
```

## Analysis
1. Organize startup records by industry and funding stage.
2. Compare funding requested with investment received.
3. Calculate deal rate and total investment by industry.
4. Compare deal outcomes by founder experience.
5. Compare deal rates across funding stages.

## Tableau dashboard
Suggested KPI cards: number of startups, number of deals, deal rate and total investment. Add charts for investment by industry, deal rate by funding stage and founder experience.

**Data note:** This is a synthetic educational dataset created to demonstrate analysis. It is not official Shark Tank India/US data and must not be presented as actual investor or founder outcomes.
